﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Xml;

namespace WebAPI
{
    public partial class Showdetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // XmlReader xmlReader = XmlReader.Create("C:\\Users\\Deepesh\\Desktop\\output-onlinexmltools.txt");
            //while (xmlReader.Read())
            //{
            //    if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "Cube"))
            //    {
            //        if (xmlReader.HasAttributes)
            //            Console.WriteLine(xmlReader.GetAttribute("currency") + ": " + xmlReader.GetAttribute("rate"));
            //    }
            //}
            //Console.ReadKey();
            string path = Server.MapPath(@"data.xml.txt");
            DataTable dt = new DataTable();
           // xmlreader xmlfile;
            XmlReader xmlfile;
            xmlfile=XmlReader.Create(path,new XmlReaderSettings());
            DataSet ds= new DataSet();
            ds.ReadXml(xmlfile);
            for(int i=0;i<ds.Tables.Count;i++)
            {
                string name = ds.Tables[0].Rows[0]["firstname"].ToString() +" " + ds.Tables[0].Rows[0]["lastname"].ToString();
                Label1.Text ="Welcome"+ " "+ name;
                Label2.Text = ds.Tables[1].Rows[0]["other"].ToString();
                Label3.Text = ds.Tables[1].Rows[0]["balance"].ToString();
            }

            }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex > 0)
            {

                if (DropDownList1.SelectedIndex == 1)
                {
                    DropDownList2.Visible = true;
                    DropDownList3.Visible = false;
                    DropDownList4.Visible = false;
                }
                if (DropDownList1.SelectedIndex == 2)
                {
                    DropDownList2.Visible =false ;
                    DropDownList3.Visible = true;
                    DropDownList4.Visible = false;
                }
                if (DropDownList1.SelectedIndex == 3)
                {
                    DropDownList2.Visible = false;
                    DropDownList3.Visible = false;
                    DropDownList4.Visible =true ;
                }
                //if (DropDownList1.SelectedIndex == 1)
                //{
                //    Label4.Text = TextBox1.Text;
                //    Label5.Text = DropDownList1.SelectedItem.Text;
                //    decimal value=Convert.ToDecimal(TextBox1.Text);
                //    decimal tax=2.5M;
                //    Label6.Text = "2.5";
                //    Label7.Text = Convert.ToString((value * tax) / 100);
                //}
                //if (DropDownList1.SelectedIndex == 2)
                //{
                //    Label4.Text = TextBox1.Text;
                //    Label5.Text = DropDownList1.SelectedItem.Text;
                //    decimal value = Convert.ToDecimal(TextBox1.Text);
                //    decimal tax = 4.2M;
                //    Label6.Text = "4.2";
                //    Label7.Text = Convert.ToString((value * tax) / 100);
                //}
                //if (DropDownList1.SelectedIndex == 3)
                //{
                //    Label4.Text = TextBox1.Text;
                //    Label5.Text = DropDownList1.SelectedItem.Text;
                //    decimal value = Convert.ToDecimal(TextBox1.Text);
                //    decimal tax = 1.0M;
                //    Label6.Text = "1";
                //    Label7.Text = Convert.ToString((value * tax) / 100);
                //}
            }

        }
        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList3.SelectedIndex > 0)
            {

                //if (DropDownList1.SelectedIndex == 1)
                //{
                //    DropDownList2.Visible = true;
                //    DropDownList3.Visible = false;
                //    DropDownList4.Visible = false;
                //}
                //if (DropDownList1.SelectedIndex == 2)
                //{
                //    DropDownList2.Visible = false;
                //    DropDownList3.Visible = true;
                //    DropDownList4.Visible = false;
                //}
                //if (DropDownList1.SelectedIndex == 3)
                //{
                //    DropDownList2.Visible = false;
                //    DropDownList3.Visible = false;
                //    DropDownList4.Visible = true;
                //}
                if (DropDownList3.SelectedIndex == 1)
                {
                    Label4.Text = TextBox1.Text;
                    Label5.Text = DropDownList1.SelectedItem.Text;
                    decimal value=Convert.ToDecimal(TextBox1.Text);
                    decimal tax=2.5M;
                    Label6.Text = "2.5";
                    Label7.Text = Convert.ToString((value * tax) / 100);
                      Label8.Text = "2";
                    Label9.Text = Convert.ToString(Convert.ToDecimal(Label7.Text)-2);
                }
                if (DropDownList3.SelectedIndex == 2)
                {
                    Label4.Text = TextBox1.Text;
                    Label5.Text = DropDownList1.SelectedItem.Text;
                    decimal value = Convert.ToDecimal(TextBox1.Text);
                    decimal tax = 4.2M;
                    Label6.Text = "4.2";
                    Label7.Text = Convert.ToString((value * tax) / 100);
                      Label8.Text = "0.9";
                    Label9.Text = Convert.ToString(Convert.ToDecimal(Label7.Text)-0.9M);
                }
               
            }

        }
        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList4.SelectedIndex > 0)
            {

               
                if (DropDownList4.SelectedIndex == 1)
                {
                    Label4.Text = TextBox1.Text;
                    Label5.Text = DropDownList1.SelectedItem.Text;
                    decimal value=Convert.ToDecimal(TextBox1.Text);
                    decimal tax=2.5M;
                    Label6.Text = "2.5";
                    Label7.Text = Convert.ToString((value * tax) / 100);
                      Label8.Text = "1.5";
                    Label9.Text = Convert.ToString(Convert.ToDecimal(Label7.Text)-1.5M);
                }
                //if (DropDownList1.SelectedIndex == 2)
                //{
                //    Label4.Text = TextBox1.Text;
                //    Label5.Text = DropDownList1.SelectedItem.Text;
                //    decimal value = Convert.ToDecimal(TextBox1.Text);
                //    decimal tax = 4.2M;
                //    Label6.Text = "4.2";
                //    Label7.Text = Convert.ToString((value * tax) / 100);
                //}
                //if (DropDownList1.SelectedIndex == 3)
                //{
                //    Label4.Text = TextBox1.Text;
                //    Label5.Text = DropDownList1.SelectedItem.Text;
                //    decimal value = Convert.ToDecimal(TextBox1.Text);
                //    decimal tax = 1.0M;
                //    Label6.Text = "1";
                //    Label7.Text = Convert.ToString((value * tax) / 100);
                //}
            }

        }
        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
                if (DropDownList2.SelectedIndex == 1)
                {
                    Label4.Text = TextBox1.Text;
                    Label5.Text = DropDownList1.SelectedItem.Text;
                    decimal value=Convert.ToDecimal(TextBox1.Text);
                    decimal tax=2.5M;
                    Label6.Text = "2.5";
                    Label7.Text = Convert.ToString((value * tax) / 100);
                    Label8.Text = "2";
                    Label9.Text = Convert.ToString(Convert.ToDecimal(Label7.Text)-2);
                }
                if (DropDownList2.SelectedIndex == 2)
                {
                    Label4.Text = TextBox1.Text;
                    Label5.Text = DropDownList1.SelectedItem.Text;
                    decimal value = Convert.ToDecimal(TextBox1.Text);
                    decimal tax = 4.2M;
                    Label6.Text = "4.2";
                    Label7.Text = Convert.ToString((value * tax) / 100);
                    Label8.Text = "1";
                    Label9.Text = Convert.ToString(Convert.ToDecimal(Label7.Text)-2);
                }
              
            }

        
        }
    }
